<?php

require "core/Validator.php";
require "core/Database.php";
$config = require "config.php";

// Create a new instance of the Database class
$db = new Database($config);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Initialize errors array
    $errors = [];

    // Validate input fields
    if (!isset($_POST["name"]) || !Validator::string($_POST["name"], min: 1, max: 255)) {
        $errors["name"] = "Title cannot be empty or too long";
    }

    if (!isset($_POST["authors"]) || !Validator::string($_POST["authors"], min: 1, max: 255)) {
        $errors["authors"] = "Authors are invalid";
    }

    if (!isset($_POST["year_came_out"]) || !Validator::string($_POST["year_came_out"], min: 1, max: 4)) {
        $errors["year_came_out"] = "Year release is invalid";
    }

    // If there are no validation errors, insert data into the database
    if (empty($errors)) {
        $query = "INSERT INTO books (name, authors, year_came_out) VALUES (:name, :authors, :year_came_out)";
        $params = [
            ":name" => $_POST["name"],
            ":authors" => $_POST["authors"],
            ":year_came_out" => $_POST["year_came_out"]
        ];

        $db->execute($query, $params);
        header('Location: /');
        exit(); // Stop execution after redirection
    }
}

// Set page title
$title = "Create a Post";

// Require the view file to display the form
require "views/books/create.view.php";
?>