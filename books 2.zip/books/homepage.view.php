<?php guest();?>
<?php require "views/components/head.php";?>
<?php require "views/components/navbars.php";?>
<div class="mid">
    <div class="typo"> 
        <div class="font-izmers">
            <h1 class="pongo">welcome to Vasarajs liberary home page</h1>
                <br></br>
                <p>to see books and more you must be logged in</p>
        </div>
    </div>
</div>
<?php require "views/components/footer.php";?>