<header>
    <nav>
        <a href="/login">login</a>
        <a href="/register">register</a>
    </nav>
</header>