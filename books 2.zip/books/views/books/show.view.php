<?php require "views/components/head.php" ?>
<?php require "views/components/navbar.php" ?>

<?php if ($post): ?>
    <div class="typo"> 
        <div class="font-izmers">
    <h1 class="text-size-font" style="margin-top:40px"><?= htmlspecialchars($post["name"]) ?></h1>
    <p class="text-size-font" style="margin-top:40px">Year Released: <?= htmlspecialchars($post["year_came_out"]) ?></p>
    <p class="text-size-font" style="margin-top:40px">Authors: <?= htmlspecialchars($post["authors"]) ?></p>
    
    </div>
    <a href="/edit?id=<?= $post["id"] ?>">Edit</a>
</div>
    
<?php else: ?>
    <p>Book not found.</p>
<?php endif; ?>

<?php require "views/components/footer.php" ?>