<?php require "views/components/head.php"; ?>
<?php require "views/components/navbar.php"; ?>
<br>
<form method="POST">
    <label for="name">Name:</label>
    <input class="got" type="text" id="name" name="name" value="<?= $_POST["name"] ?? "" ?>">
    <?php if (isset($errors["name"])) { ?>
        <p class="invalid-data"><?= $errors["name"] ?></p>
    <?php } ?>
    
    <label  for="authors">Authors:</label>
    <input class="got" type="text" id="authors" name="authors" value="<?= $_POST["authors"] ?? "" ?>">
    <?php if (isset($errors["authors"])) { ?>
        <p class="invalid-data"><?= $errors["authors"] ?></p>
    <?php } ?>

    <label for="year_came_out">Release Year:</label>
    <input class="got"type="text" id="year_came_out" name="year_came_out" value="<?= $_POST["year_came_out"] ?? "" ?>">
    <?php if (isset($errors["year_came_out"])) { ?>
        <p class="invalid-data"><?= $errors["year_came_out"] ?></p>
    <?php } ?>
    
    <button type="submit">Save</button>
</form>

<?php require "views/components/footer.php"; ?>