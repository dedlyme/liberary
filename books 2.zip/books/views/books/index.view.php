<?php require "views/components/head.php"; ?>
<?php require "views/components/navbar.php"; ?>

<h1 class="h1">Books</h1>

<ul>
    <?php foreach($posts as $post) { ?>
        <li> <div class="text-size-font">
            <a href="/show?id=<?= $post["id"] ?>">
                <?= htmlspecialchars($post["name"]) ?> by <?= htmlspecialchars($post["authors"]) ?> (<?= htmlspecialchars($post["year_came_out"]) ?>)
            </a>
            </div>
            <!-- Add the delete button -->
            <form class="delete-form" method="POST" action="/delete">
                <input type="hidden" name="id" value="<?= $post["id"] ?>">
                <button type="submit">Delete</button>
            </form>
        </li>
    <?php } ?>
</ul>

<?php require "views/components/footer.php"; ?>