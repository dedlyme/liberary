<?php require "views/components/head.php";?>
<?php require "views/components/navbar.php";?>

<h1>Edit a post</h1>

<form method="POST">
<input name="id" value="<?= $post["id"] ?>" type="hidden" />
    <label>name:
    <input name="name" value="<?= $_POST["name"] ?? $post["name"]?>">
    <?php if (isset($errors["name"])){ ?>
    <p class="invalid-data"><?= $errors["name"] ?></p>
<?php } ?>
    </label>

    <input name="id" value="<?= $post["id"] ?>" type="hidden" />
    <label>authors:
    <input name="authors" value="<?= $_POST["authors"] ?? $post["authors"]?>">
    <?php if (isset($errors["authors"])){ ?>
    <p class="invalid-data"><?= $errors["authors"] ?></p>
<?php } ?>
    </label>

    <input name="id" value="<?= $post["id"] ?>" type="hidden" />
    <label>release year:
    <input name="year_came_out" value="<?= $_POST["year_came_out"] ?? $post["year_came_out"]?>">
    <?php if (isset($errors["year_came_out"])){ ?>
    <p class="invalid-data"><?= $errors["year_came_out"] ?></p>
<?php } ?>
    </label>



    <button class="button-27">Save</button>
</form>

<?php require "views/components/footer.php";?>