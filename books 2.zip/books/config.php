<?php

return [
  "host" => "localhost",
  "dbname" => "gramatas",
  "user" => "root",
  "password" => "root",
  "charset" => "utf8mb4"
];